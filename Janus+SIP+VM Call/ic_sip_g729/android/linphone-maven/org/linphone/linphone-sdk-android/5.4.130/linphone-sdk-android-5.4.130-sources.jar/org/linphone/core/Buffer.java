/*
Buffer.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* The object representing a data buffer. <br/>
* <br/>
*/
public interface Buffer {
    /**
    * Get the content of the data buffer. <br/>
    * <br/>
    * @return The content of the data buffer.    <br/>
    */
    @NonNull
    public byte[] getContent();

    /**
    * Tell whether the {@link Buffer} is empty. <br/>
    * <br/>
    * @return A boolean value telling whether the {@link Buffer} is empty or not. <br/>
    */
    public boolean isEmpty();

    /**
    * Get the size of the content of the data buffer. <br/>
    * <br/>
    * @return The size of the content of the data buffer. <br/>
    */
    public int getSize();

    /**
    * Set the size of the content of the data buffer. <br/>
    * <br/>
    * @param size The size of the content of the data buffer. <br/>
    */
    public void setSize(int size);

    /**
    * Get the string content of the data buffer. <br/>
    * <br/>
    * @return The string content of the data buffer.    <br/>
    */
    @NonNull
    public String getStringContent();

    /**
    * Set the string content of the data buffer. <br/>
    * <br/>
    * @param content The string content of the data buffer.    <br/>
    */
    public void setStringContent(@NonNull String content);

    /**
    * Set the content of the data buffer. <br/>
    * <br/>
    * @param content The content of the data buffer.    <br/>
    * @param size The size of the content of the data buffer. <br/>
    */
    public void setContent(@NonNull byte[] content, int size);

    /**
    * Create a new {@link Buffer} object from existing data. <br/>
    * <br/>
    * @param data The initial data to store in the LinphoneBuffer.    <br/>
    * @param size The size of the initial data to store in the LinphoneBuffer. <br/>
    * @return A new {@link Buffer} object.    <br/>
    */
    @NonNull
    public Buffer newFromData(@NonNull byte[] data, int size);

    /**
    * Create a new {@link Buffer} object from a string. <br/>
    * <br/>
    * @param data The initial string content of the LinphoneBuffer.    <br/>
    * @return A new {@link Buffer} object.    <br/>
    */
    @NonNull
    public Buffer newFromString(@NonNull String data);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class BufferImpl implements Buffer {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected BufferImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native byte[] getContent(long nativePtr);
    @Override @NonNull
    synchronized public byte[] getContent()  {
        
        
        return getContent(nativePtr);
    }

    private native boolean isEmpty(long nativePtr);
    @Override
    synchronized public boolean isEmpty()  {
        
        
        return isEmpty(nativePtr);
    }

    private native int getSize(long nativePtr);
    @Override
    synchronized public int getSize()  {
        
        
        return getSize(nativePtr);
    }

    private native void setSize(long nativePtr, int size);
    @Override
    synchronized public void setSize(int size)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSize() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSize(nativePtr, size);
    }

    private native String getStringContent(long nativePtr);
    @Override @NonNull
    synchronized public String getStringContent()  {
        
        
        return getStringContent(nativePtr);
    }

    private native void setStringContent(long nativePtr, String content);
    @Override
    synchronized public void setStringContent(@NonNull String content)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setStringContent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setStringContent(nativePtr, content);
    }

    private native void setContent(long nativePtr, byte[] content, int size);
    @Override
    synchronized public void setContent(@NonNull byte[] content, int size)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setContent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setContent(nativePtr, content, size);
    }

    private native Buffer newFromData(long nativePtr, byte[] data, int size);
    @Override @NonNull
    synchronized public Buffer newFromData(@NonNull byte[] data, int size)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call newFromData() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Buffer)newFromData(nativePtr, data, size);
    }

    private native Buffer newFromString(long nativePtr, String data);
    @Override @NonNull
    synchronized public Buffer newFromString(@NonNull String data)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call newFromString() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Buffer)newFromString(nativePtr, data);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
